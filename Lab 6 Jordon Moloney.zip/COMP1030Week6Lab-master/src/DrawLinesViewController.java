import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javax.swing.*;
import java.net.URL;
import java.util.ResourceBundle;

public class DrawLinesViewController implements Initializable {

    @FXML
    private Canvas canvas;

    @FXML
    private ImageView lPatternImageView;

    @FXML
    private ImageView footballPatternImageView;

    @FXML
    private ImageView threeQuartersImageView;

    @FXML
    private ImageView fullImageView;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lPatternImageView.setImage(new Image("L-pattern.png"));
        footballPatternImageView.setImage(new Image("footballPattern.png"));
        threeQuartersImageView.setImage(new Image("3Quarters.png"));
        fullImageView.setImage(new Image("full.png"));
    }




    @FXML
    public void drawXButtonPressed()
    {
        GraphicsContext gc = clearCanvasAndGetGraphicsContext();

        //draw line from top corner to bottom corner
        gc.strokeLine(0, 0, canvas.getWidth(), canvas.getHeight());

        //draw line from bottom left corner to upper right corner
        gc.strokeLine(0, canvas.getHeight(), canvas.getWidth(), 0);
    }

    @FXML
    public void drawLPatternButtonPressed()
    {
        GraphicsContext gc = clearCanvasAndGetGraphicsContext();
        Image Lshape = new Image("L-pattern.png"); //Referencing the L shaped Image
        gc.drawImage(Lshape, 0, -20); //Drawing the image when the button is selected (the reason as to why
                                             // the y coordinate is -20 rather than 0 is because the bottom of the
                                             // image was being cut off for the L shaped one
    }

    @FXML
    public void footballPatternButtonPressed()
    {
        GraphicsContext gc = clearCanvasAndGetGraphicsContext();
        Image FBshape = new Image("footballPattern.png"); //Referencing the football shaped Image
        gc.drawImage(FBshape, 0, 0);
    }

    @FXML
    public void threeQuartersPatternButtonPressed()
    {
        GraphicsContext gc = clearCanvasAndGetGraphicsContext();
        Image TQshape = new Image("3Quarters.png"); //Referencing the Three Quarters shaped Image
        gc.drawImage(TQshape, 0, 0);
    }

    @FXML
    public void fullPatternButtonPressed()
    {
        GraphicsContext gc = clearCanvasAndGetGraphicsContext();
        Image Fshape = new Image("full.png"); //Referencing the Full shaped Image
        gc.drawImage(Fshape, 0, 0);
    }

    public GraphicsContext clearCanvasAndGetGraphicsContext()
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();

        //clear the canvas
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

        return gc;
    }
}
